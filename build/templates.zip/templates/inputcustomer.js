<script>
	$(document).ready(function() {
		$('#cust_id').attr('placeholder', 'Cédula' );
	});
</script>